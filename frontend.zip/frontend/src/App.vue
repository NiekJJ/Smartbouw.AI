<template>
  <div>
    <h1>🏗️ ERP App</h1>
    <KlantenOverzicht />
  </div>
</template>

<script>
import KlantenOverzicht from './components/KlantenOverzicht.vue'

export default {
  components: {
    KlantenOverzicht
  }
}
</script>